class ChatHistory extends HTMLElement {
  constructor() {
    super();
    this.shadow = this.attachShadow({ mode: "open" });
    this.shadow.innerHTML = /* html */ `
      <style>
        :host {
          display: flex;
          width: 100%;
          height: 100%;
          min-width: 0;
          min-height: 0;
          flex: 1 1 auto;
          overflow: hidden;
          box-sizing: border-box;
          color: hsl(0, 0%, 96%);
          transition: color 0.3s ease;
        }
        .chat-history {
          display: flex;
          flex-direction: column;
          width: 100%;
          height: 100%;
          min-width: 0;
          min-height: 0;
          overflow: hidden;
          box-sizing: border-box;
        }
        .chat-history-button {
          display: flex;
          width: 100%;
          height: auto;
          min-width: 0;
          align-items: center;
          gap: 0.625rem;
          padding: 0.75rem 0.9375rem;
          margin: 0 0 0.75rem 0;
          flex-shrink: 0;
          border: 0.0625rem solid hsl(0, 0%, 22%);
          border-radius: 0.5rem;
          background: hsl(0, 0%, 13%);
          color: hsl(0, 0%, 96%);
          font-family: inherit;
          font-size: 0.875rem;
          font-weight: 400;
          line-height: 1.4;
          text-align: left;
          cursor: pointer;
          box-sizing: border-box;
          transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease;
        }
        .chat-history-button:hover {
          background: hsl(0, 0%, 17%);
          border-color: hsl(0, 0%, 28%);
          color: hsl(0, 0%, 96%);
        }
        .chat-history-button:active {
          background: hsl(0, 0%, 19%);
        }
        .chat-history-button:focus-visible {
          outline: 0.125rem solid hsl(0, 0%, 70%);
          outline-offset: 0.125rem;
        }
        .chat-history-icon {
          position: relative;
          display: block;
          width: 1rem;
          height: 1rem;
          min-width: 1rem;
          min-height: 1rem;
          border: 0.0625rem solid currentColor;
          border-radius: 0.1875rem;
          box-sizing: border-box;
          flex-shrink: 0;
        } 
        .chat-history-icon::before,
        .chat-history-icon::after {
          content: "";
          position: absolute;
          left: 0.1875rem;
          width: 0.5rem;
          height: 0.0625rem;
          background: currentColor;
          border-radius: 0.0625rem;
        }
        .chat-history-icon::before {
          top: 0.3125rem;
        }
        .chat-history-icon::after {
          top: 0.5625rem;
        }
        .chat-history-title {
          display: block;
          min-width: 0;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
        .chat-history-list {
          display: flex;
          flex-direction: column;
          width: 100%;
          height: 100%;
          min-width: 0;
          min-height: 0;
          gap: 0.1875rem;
          overflow-x: hidden;
          overflow-y: auto;
          box-sizing: border-box;
          scrollbar-width: thin;
          scrollbar-color: hsl(0, 0%, 28%) transparent;
        }
        .chat-history-list::-webkit-scrollbar {
          width: 0.375rem;
        }
        .chat-history-list::-webkit-scrollbar-track {
          background: transparent;
        }
        .chat-history-list::-webkit-scrollbar-thumb {
          background: hsl(0, 0%, 28%);
          border-radius: 0.5rem;
        }
        .chat-history-list::-webkit-scrollbar-thumb:hover {
          background: hsl(0, 0%, 38%);
        }
        .chat-history-item {
          width: 100%;
          min-width: 0;
          flex-shrink: 0;
        }
        .chat-history-link {
          display: block;
          width: 100%;
          min-width: 0;
          padding: 0.3rem 0.4rem;
          border: 0;
          border-radius: 0.4375rem;
          background: transparent;
          color: hsl(0, 0%, 70%);
          font-family: inherit;
          font-size: 0.875rem;
          font-weight: 400;
          line-height: 1.4;
          text-decoration: none;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
          box-sizing: border-box;
          cursor: pointer;
          transition: background-color 0.3s ease, color 0.3s ease;
        }
        .chat-history-link:hover {
          background: hsl(0, 0%, 14%);
          color: hsl(0, 0%, 96%);
        }
        .chat-history-link:focus-visible {
          outline: 0.125rem solid hsl(0, 0%, 70%);
          outline-offset: -0.0625rem;
        }
        :host([data-theme="light"]) {
          color: hsl(0, 0%, 10%);
        }
        :host([data-theme="light"]) .chat-history-button {
          background: hsl(0, 0%, 94%);
          border-color: hsl(0, 0%, 82%);
          color: hsl(0, 0%, 15%);
        }
        :host([data-theme="light"]) .chat-history-button:hover {
          background: hsl(0, 0%, 90%);
          border-color: hsl(0, 0%, 76%);
        }
        :host([data-theme="light"]) .chat-history-button:active {
          background: hsl(0, 0%, 87%);
        }
        :host([data-theme="light"]) .chat-history-link {
          color: hsl(0, 0%, 35%);
        }
        :host([data-theme="light"]) .chat-history-link:hover {
          background: hsl(0, 0%, 92%);
          color: hsl(0, 0%, 10%);
        }
        :host([data-theme="light"]) .chat-history-list {
          scrollbar-color: hsl(0, 0%, 72%) transparent;
        }
        :host([collapsed]) .chat-history-button {
          width: 2.625rem;
          height: 2.625rem;
          min-width: 2.625rem;
          min-height: 2.625rem;
          justify-content: center;
          gap: 0;
          padding: 0;
          margin: 0 auto 0.75rem auto;
          border-radius: 0.5rem;
        }
        :host([collapsed]) .chat-history-title {
          display: none;
        }
        :host([collapsed]) .chat-history-list {
          display: none;
        }
        @media (max-width: 64rem) {

          .chat-history-button {
            width: 100%;
            height: auto;
            justify-content: flex-start;
            gap: 0.625rem;
            padding: 0.75rem 0.9375rem;
            margin: 0 0 0.75rem 0;
            border-radius: 0.5rem;
          }
          .chat-history-title {
            display: block;
          }
          .chat-history-list {
            display: flex;
            gap: 0.1875rem;
          }
          :host([collapsed]) .chat-history-button {
            width: 100%;
            height: auto;
            min-width: 0;
            min-height: 0;
            justify-content: flex-start;
            gap: 0.625rem;
            padding: 0.75rem 0.9375rem;
            margin: 0 0 0.75rem 0;
            border-radius: 0.5rem;
          }
          :host([collapsed]) .chat-history-title {
            display: block;
          }
          :host([collapsed]) .chat-history-list {
            display: flex;
          }
        }
        @media (max-width: 30rem) {
          .chat-history-button {
            padding: 0.75rem;
            margin-bottom: 0.75rem;
          }
          .chat-history-link {
            padding: 0.4rem 0.5625rem;
          }
          :host([collapsed]) .chat-history-button {
            padding: 0.75rem;
            margin-bottom: 0.75rem;
          }
        }
        @media (max-width: 22rem) {
          .chat-history-button {
            padding: 0.6875rem 0.75rem;
            margin-bottom: 0.6875rem;
          }
          .chat-history-link {
            padding: 0.375rem 0.5rem;
          }
          :host([collapsed]) .chat-history-button {
            padding: 0.6875rem 0.75rem;
            margin-bottom: 0.6875rem;
          }
        }
        @media (max-height: 40rem) {
          .chat-history-button {
            margin-bottom: 0.625rem;
          }
        }
      </style>
      <div class="chat-history">
        <button type="button" class="chat-history-button" aria-label="Historial de chats">
          <span class="chat-history-icon" aria-hidden="true"></span>
          <span class="chat-history-title">
            Historial de chats
          </span>
        </button>
        <div class="chat-history-list">
        </div>
      </div>
    `;
    this.data = [
      {
        "nombre": "Cómo conectar un JSON con JavaScript",
        "href": "#"
      },
      {
        "nombre": "Revisar estructura de Web Components",
        "href": "#"
      },
      {
        "nombre": "Ideas para mejorar el diseño de mi aplicación",
        "href": "#"
      },
      {
        "nombre": "Explicación sencilla de fetch() y async/await",
        "href": "#"
      },
      {
        "nombre": "Cómo organizar un proyecto JavaScript por componentes",
        "href": "#"
      },
      {
        "nombre": "Crear un menú dinámico a partir de un archivo JSON",
        "href": "#"
      },
      {
        "nombre": "Diferencias entre Shadow DOM y DOM tradicional",
        "href": "#"
      },
      {
        "nombre": "Corregir un problema de flexbox en CSS",
        "href": "#"
      },
      {
        "nombre": "Cómo hacer que una interfaz sea responsive",
        "href": "#"
      },
      {
        "nombre": "Ideas para una novela de ciencia ficción",
        "href": "#"
      },
      {
        "nombre": "Desarrollar la historia de Rhodvar Varykhen",
        "href": "#"
      },
      {
        "nombre": "Nuevas civilizaciones para mi universo",
        "href": "#"
      },
      {
        "nombre": "Diseñar un sistema de viajes entre dimensiones",
        "href": "#"
      },
      {
        "nombre": "Cómo construir un misterio progresivo para una novela",
        "href": "#"
      },
      {
        "nombre": "Revisar el capítulo inicial de mi novela",
        "href": "#"
      },
      {
        "nombre": "Nombres para una organización secreta de ciencia ficción",
        "href": "#"
      },
      {
        "nombre": "Ideas para una interfaz de chat similar a ChatGPT",
        "href": "#"
      },
      {
        "nombre": "Cambiar los colores de la interfaz al modo claro",
        "href": "#"
      },
      {
        "nombre": "Problema con el botón hamburguesa en móvil",
        "href": "#"
      },
      {
        "nombre": "Cómo guardar conversaciones en JSON",
        "href": "#"
      },
      {
        "nombre": "Crear una paginación sencilla con JavaScript",
        "href": "#"
      },
      {
        "nombre": "Explicación de clases y métodos en JavaScript",
        "href": "#"
      },
      {
        "nombre": "Qué estructura debería tener mi proyecto web",
        "href": "#"
      },
      {
        "nombre": "Ideas para mejorar mi portfolio de programación",
        "href": "#"
      },
      {
        "nombre": "Cómo optimizar el CSS sin cambiar el diseño",
        "href": "#"
      },
      {
        "nombre": "Revisar errores en mi código JavaScript",
        "href": "#"
      },
      {
        "nombre": "Crear componentes reutilizables con Web Components",
        "href": "#"
      },
      {
        "nombre": "Cómo funciona connectedCallback()",
        "href": "#"
      },
      {
        "nombre": "Diferencias entre atributos y propiedades en HTML",
        "href": "#"
      },
      {
        "nombre": "Diseñar una aplicación de escritorio con HTML, CSS y JavaScript",
        "href": "#"
      },
      {
        "nombre": "Ideas para una novela interactiva donde el lector pueda elegir su camino",
        "href": "#"
      },
      {
        "nombre": "Cómo guardar el estado de una historia interactiva",
        "href": "#"
      },
      {
        "nombre": "Crear un sistema de relaciones entre personajes",
        "href": "#"
      },
      {
        "nombre": "Desarrollar la mitología de los Vaerum",
        "href": "#"
      },
      {
        "nombre": "Revisar la continuidad y coherencia de mi universo",
        "href": "#"
      },
      {
        "nombre": "Ideas para nombres de planetas y sistemas estelares",
        "href": "#"
      },
      {
        "nombre": "Cómo escribir diálogos naturales entre personajes",
        "href": "#"
      },
      {
        "nombre": "Mejorar el ritmo de una escena de acción",
        "href": "#"
      },
      {
        "nombre": "Cómo evitar explicaciones innecesarias en una novela",
        "href": "#"
      },
      {
        "nombre": "Ideas para un nuevo proyecto personal",
        "href": "#"
      },
      {
        "nombre": "Preguntas sobre HTML y CSS",
        "href": "#"
      },
      {
        "nombre": "Conversación especialmente larga cuyo título debería cortarse automáticamente en la interfaz",
        "href": "#"
      }
    ];
    this.historyButton = this.shadowRoot.querySelector(".chat-history-button");
    this.historyList = this.shadowRoot.querySelector(".chat-history-list");
    this.handleHistoryButton = this.handleHistoryButton.bind(this);
    this.handleHistoryLink = this.handleHistoryLink.bind(this);
  }
  connectedCallback() {
    this.loadData();
    this.syncWithSidebar();
  }
  disconnectedCallback() {
    this.historyButton.removeEventListener("click", this.handleHistoryButton);
    this.historyLinks.forEach((link) => {
      link.removeEventListener("click", this.handleHistoryLink);
    });
  }
  loadData() {
    this.renderLinks();
    this.historyButton.addEventListener("click", this.handleHistoryButton);
    this.historyLinks.forEach((link) => {
      link.addEventListener("click", this.handleHistoryLink);
    });
  }
  renderLinks() {
    this.historyList.innerHTML = "";
    this.renderData(this.data, this.historyList);
    this.historyLinks = this.shadowRoot.querySelectorAll(".chat-history-link");
  }
  renderData(datos, contenedor, ruta = "") {
    if (Array.isArray(datos)) {
      if (!datos.length) {
        this.crearEnlace("[]", contenedor);
        return;
      }
      datos.forEach((dato, indice) => {
        this.renderData(dato, contenedor, ruta ? `${ruta}[${indice}]` : `[${indice}]`);
      });
      return;
    }
    if (datos && typeof datos === "object") {
      const claves = Object.keys(datos);
      if (!claves.length) {
        this.crearEnlace(`${ruta || "objeto"}: {}`, contenedor);
        return;
      }
      const href = typeof datos.href === "string" ? datos.href : "#";
      claves.forEach((clave) => {
        if (clave === "href") {
          return;
        }
        const valor = datos[clave];
        const nuevaRuta = ruta ? `${ruta}.${clave}` : clave;
        if (valor && typeof valor === "object") {
          this.crearEnlace(clave, contenedor, href);
          this.renderData(valor, contenedor, nuevaRuta);
        } else {
          this.crearEnlace(
            clave === "nombre" && Object.keys(datos).length <= 2
              ? this.formatearValor(valor)
              : `${clave}: ${this.formatearValor(valor)}`,
            contenedor,
            href
          );
        }
      });
      return;
    }
    this.crearEnlace(`${ruta ? `${ruta}: ` : ""}${this.formatearValor(datos)}`, contenedor);
  }
  crearEnlace(texto, contenedor, href = "#") {
    const item = document.createElement("div");
    item.className = "chat-history-item";
    const enlace = document.createElement("a");
    enlace.href = href;
    enlace.classList.add("chat-history-link");
    enlace.textContent = texto;
    item.append(enlace);
    contenedor.append(item);
  }
  formatearValor(valor) {
    if (valor === null) {
      return "null";
    }
    if (valor === undefined) {
      return "undefined";
    }
    return String(valor);
  }
  handleHistoryButton(event) {
    event.preventDefault();
    if (window.innerWidth > 1024 && this.hasAttribute("collapsed")) {
      this.dispatchEvent(
        new CustomEvent("sidebar-open-request", {
          bubbles: true,
          composed: true
        }
        )
      );
    }
  }
  handleHistoryLink(event) {
    event.preventDefault();
    if (window.innerWidth <= 1024) {
      this.dispatchEvent(
        new CustomEvent("sidebar-close-request", {
          bubbles: true,
          composed: true
        }
        )
      );
    }
  }
  syncWithSidebar() {
    const sidebar = this.closest("chat-sidebar");
    if (!sidebar) {
      return;
    }
    const theme = sidebar.getAttribute("data-theme") || "dark";
    const collapsed = sidebar.hasAttribute("collapsed");
    this.setAttribute("data-theme", theme);
    if (collapsed) {
      this.setAttribute("collapsed", "");
    } else {
      this.removeAttribute("collapsed");

    }
  }
}
customElements.define("chat-history", ChatHistory);